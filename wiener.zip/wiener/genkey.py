from Crypto.Util.number import *


with open('plaintext.txt', 'r', encoding='utf-8') as file:
    FLAG = file.read()
FLAG = "Successfully! \n\n" + FLAG

def encrypt(message, e, n):
    # Encrypt message
    return pow(message, e, n)
# Generate random p, q
p = getPrime(256) 
q = getPrime(256)

# Generate random d 
d = getPrime(120)


n = p * q   
phi_n = (p - 1) * (q - 1)  # Calc Euler's Totient function

# Choose e while 1 < e < phi_n and gcd(e, phi_n) = 1
e = inverse(d, phi_n)

FLAG_bytes = FLAG.encode()
message = bytes_to_long(FLAG_bytes)
print(f"Public Key (e, n): ({e}, {n})")

encrypted_message = encrypt(message, e, n)
print("Encrypted message:", encrypted_message)
